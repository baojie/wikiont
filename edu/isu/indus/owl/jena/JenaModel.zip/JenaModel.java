package edu.isu.indus.owl.jena;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.vocabulary.VCARD;

public class JenaModel
{
    String ontURI;

    // create an empty model
    static OntModel model = ModelFactory.createOntologyModel();

    public JenaModel(String uri)
    {
        ontURI = uri;
    }

    void sampleModel()
    {
        // some definitions
        String personURI = "http://somewhere/JohnSmith";
        String givenName = "John";
        String familyName = "Smith";
        String fullName = givenName + " " + familyName;

        // create the resource
        //   and add the properties cascading style
        Resource johnSmith
            = model.createResource(personURI)
            .addProperty(VCARD.FN, fullName)
            .addProperty(VCARD.N,
                         model.createResource()
                         .addProperty(VCARD.Given, givenName)
                         .addProperty(VCARD.Family, familyName));

    }

    /**
     *
     * @param className String
     * @return OntClass
     *
     * @author Jie Bao
     * @version 2003-03-05
     */
    public OntClass addClass(String className)
    {
        String uri = ontURI + "#" + className;
        OntClass res = model.createClass(uri);
        return res;
    }

    void listTriple()
    {

        // list the statements in the graph
        StmtIterator iter = model.listStatements();

        // print out the predicate, subject and object of each statement
        while (iter.hasNext())
        {
            Statement stmt = iter.nextStatement(); // get next statement
            Resource subject = stmt.getSubject(); // get the subject
            Property predicate = stmt.getPredicate(); // get the predicate
            RDFNode object = stmt.getObject(); // get the object

            System.out.print(subject.toString());
            System.out.print(" " + predicate.toString() + " ");
            if (object instanceof Resource)
            {
                System.out.print(object.toString());
            }
            else
            {
                // object is a literal
                System.out.print(" \"" + object.toString() + "\"");
            }
            System.out.println(" .");
        }
    }

    void writeOntology(OutputStream out)
    {
        // now write the model in XML form to a file
        model.write(System.out, "RDF/XML-ABBREV");
        //model.write(System.out, "N-TRIPLE");
    }

    void readOntology(InputStream in)
    {
        // read the RDF/XML file
        model.read(new InputStreamReader(in), "");
    }

    // for test purpose
    public static void main(String args[])
    {
        try
        {
            JenaModel t = new JenaModel("http://somewhere/");
            //t.sampleModel();
            OntClass baojie =  t.addClass("BaoJie");
            OntClass human =  t.addClass("Human");
            baojie.addSuperClass(human);

           // t.listTriple();
            System.out.println();
            t.writeOntology(System.out);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
